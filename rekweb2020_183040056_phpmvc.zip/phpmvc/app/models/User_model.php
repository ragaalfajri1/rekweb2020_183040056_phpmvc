<?php 

class User_model{
	private $nama = 'Raga Alfajri';


	public function getUser()
	{
		return $this->nama;
	}



}



 ?>