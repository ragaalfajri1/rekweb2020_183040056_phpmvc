<div class="container">
	<h1 class="mt-4">About Me</h1>
	<img src="<?= BASEURL; ?>/img/raga.jpg" alt="Raga Alfajri" width="200" class="rounded-circle shadow">
	<p class="mt-2">Hallo, Nama saya <?= $data['nama']; ?> , Umur saya <?= $data['umur']; ?> tahun , Saya seorang <?= $data['pekerjaan'] ?></p>
</div>